tags_metadata = [
    {
        "name": "auth",
        "description": "It handles the login , registration and verification",
    },
    {
        "name": "vocabapi",
        "description": "Read and write vocab from/to server"
    },
    {
        "name": "students",
        "description": "read/write stats to server for student"
    },

    {
        "name": "users",
        "description": "get, edit and delete user(s)",
        #        "externalDocs": {
        #            "description": "Items external docs",
        #            "url": "https://fastapi.tiangolo.com/",

        #       },

    },
]
