# Vocab-server
### Admin-Note
The database `sli` `(means stay logged in)` will grow and grow, so recreating it will shrink the database-size.
**Note:** If you do so, everyone will be logged out.
